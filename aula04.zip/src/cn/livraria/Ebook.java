package cn.livraria;
public class Ebook {
}
